package roadgraph;

import geography.GeographicPoint;

/**
 * @author Saylee Pradhan
 * 
 * A class which represents an edge between geographic locations
 *  
 *
 */
public class MapEdge{
	GeographicPoint start;
	GeographicPoint end;
	String roadName;
	String roadType;
	double length;
	
	public MapEdge(){
		
	}
	public MapEdge(GeographicPoint start, GeographicPoint end,
			String roadName, String roadType, double length){
		this.start = start ; 
		this.end = end;
		this.roadName = roadName;
		this.roadType = roadType;
		this.length = length;
	}
	
	public GeographicPoint getEndLocation(){
		return this.end;
	}
}
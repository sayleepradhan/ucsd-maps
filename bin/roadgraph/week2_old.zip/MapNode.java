package roadgraph;

import java.util.ArrayList;
import java.util.List;

import geography.GeographicPoint;

class MapNode{
	GeographicPoint location;
	List<MapEdge> edges;
	public MapNode(){
		
	}
	public MapNode(GeographicPoint location){
		this.location = location;
		edges = new ArrayList<MapEdge>();
	}
	public GeographicPoint getLocation(){
		return location;
	}
	public List<MapEdge> getEdges(){
		List<MapEdge> edgeList = new ArrayList<>(this.edges);
		return edgeList;
		
	}
}

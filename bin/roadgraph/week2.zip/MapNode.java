package roadgraph;

import java.util.ArrayList;
import java.util.List;

import geography.GeographicPoint;

/**
 * @author SP
 * 
 * A class which represents a node in a graph
 * A node here depicts a geographic location in a map.
 *
 */
class MapNode{
	GeographicPoint location;
	List<MapEdge> edges;
	
	/** 
	 * Create a new empty MapNode
	 */
	public MapNode(){
		
	}
	
	/** 
	 * Create a MapNode with parameters
	 */ 
	public MapNode(GeographicPoint location){
		this.location = location;
		edges = new ArrayList<MapEdge>();
	}
	
	/** Get the location of node
	 * @return The geographic location corresponding to a node in the map
	 */
	public GeographicPoint getLocation(){
		return (GeographicPoint) location.clone();
	}
	
	/** Get the list of edges
	 * @return The list of all edges connected to the map node
	 */
	public List<MapEdge> getEdges(){
		List<MapEdge> edgeList = new ArrayList<>(this.edges);
		return edgeList;
	}
	
	
}
